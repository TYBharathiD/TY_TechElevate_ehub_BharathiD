package com.tyss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ehubApplication {

	public static void main(String[] args) {
		SpringApplication.run(ehubApplication.class, args);
	}
	
}
