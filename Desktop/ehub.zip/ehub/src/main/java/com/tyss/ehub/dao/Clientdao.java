package com.tyss.ehub.dao;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.tyss.ehub.dto.Billable;
import com.tyss.ehub.dto.ClientsInfo;

public interface Clientdao {

	public boolean insert(ClientsInfo clientinfo);

	public boolean delete(int clientId);

	public boolean update(ClientsInfo clientinfo);

	public List<ClientsInfo> getAllClients();

	public ClientsInfo getAllComp();
	
	public Map<Integer, Integer> getCountBillable();
	
	public ClientsInfo getClientDeatils(int id);

}
