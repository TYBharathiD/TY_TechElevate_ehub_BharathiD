import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packageform',
  templateUrl: './packageform.component.html',
  styleUrls: ['./packageform.component.css']
})
export class PackageformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
