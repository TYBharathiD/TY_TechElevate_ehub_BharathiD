package com.tyss.EngineersManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngineersManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
